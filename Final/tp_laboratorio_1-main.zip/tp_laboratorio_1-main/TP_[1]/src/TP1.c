#include <stdio.h>
#include <stdlib.h>
#include "viajes.h"

int main(void){
	numero();
	return 0;
}

